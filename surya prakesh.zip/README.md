# 📈 Stock Market Data Analysis Dashboard

A simple, beginner-friendly stock market analytics dashboard built with **Python**, **Pandas**, **Matplotlib**, and **Streamlit**. 

This project is tailored for academic learning and mini-project submissions. It enables users to explore historical stock prices, analyze trading volumes, calculate daily and monthly investment metrics, and visualize market performance through interactive charts.

---

## 📌 Project Overview & Objectives

* **Objective:** Provide a clear, intuitive visual analytics dashboard for historical stock market data.
* **Beginner-Friendly Architecture:** Organized into modular, clean Python functions without requiring complex frameworks, machine learning, or external database setups.
* **Offline-Ready:** Works immediately out of the box using the included realistic sample dataset (`stock_data.csv`), while also providing flexibility to upload custom CSV files or query live ticker data via `yfinance`.
* **Zero Configuration:** No API keys or paid accounts required.

---

## 🚀 Key Features

### 1. Dataset Management
* **Instant Sample Data:** Pre-packaged with `stock_data.csv` containing 90 trading days of realistic price and volume data.
* **Custom CSV Upload:** Upload any stock CSV dataset containing `Date`, `Open`, `High`, `Low`, `Close`, and `Volume`.
* **Optional Live Market Fetching:** Built-in integration with `yfinance` to fetch live historical data for any ticker (e.g., `AAPL`, `MSFT`, `GOOGL`, `TSLA`, `INFY`).
* **Interactive Date Filtering:** Dynamic date range picker that updates all summary statistics and charts instantaneously.
* **Interactive Data Table:** Formatted view of all price figures, volume counts, and percentage returns with a one-click CSV export option.

### 2. Statistical Analysis & Key Performance Indicators (KPIs)
Calculates and displays critical stock metrics:
* **Latest Closing Price:** The most recent closing valuation in the selected period.
* **Highest Stock Price:** Peak price reached within the selected timeframe.
* **Lowest Stock Price:** Lowest intraday price reached within the period.
* **Average Closing Price:** Arithmetic mean of closing prices.
* **Total Trading Volume:** Cumulative volume traded across all selected trading days.
* **Overall Period Return (%):** Net percentage change between the starting and ending close prices.

### 3. Data Visualizations (Matplotlib)
Generates 5 distinct financial charts:
1. **Historical Closing Price Trend (Line Chart):** Visualizes closing price movements over time with subtle gradient shading.
2. **Daily Trading Volume (Bar Chart):** Displays daily volume with green/red color encoding indicating positive or negative daily closing movement.
3. **Open vs. Close Price Comparison (Line Chart):** Compares opening versus closing levels to evaluate intraday price action.
4. **Daily Returns Distribution (Histogram):** Plots the frequency distribution of daily price percentage returns along with the mean return reference line.
5. **Monthly Average Closing Price (Bar Chart):** Aggregates daily closing prices by month with precise price labels on top of each bar.

### 4. Returns & Performance Highlights
* **Daily Percentage Return Formula:**
  $$\text{Daily Return} = \left(\frac{\text{Current Close} - \text{Previous Close}}{\text{Previous Close}}\right) \times 100$$
* **Best-Performing Day:** Highest single-day gain and date.
* **Worst-Performing Day:** Steepest single-day decline and date.
* **Average Daily Return:** Mean daily return percentage.

---

## 🛠️ Technologies Used

* **Python 3.9+**: Core programming language.
* **Pandas**: Data manipulation, cleaning, aggregation, and time series handling.
* **Matplotlib**: Financial charting, histograms, and visualization.
* **Streamlit**: Interactive web dashboard and user interface.
* **yfinance (Optional)**: Fetching historical stock quotes online.

---

## 📂 Project Structure

```text
stock-market-analysis/
│
├── app.py                # Main Streamlit dashboard application
├── stock_data.csv        # Pre-packaged 90-day realistic sample dataset
├── requirements.txt      # Project dependencies
└── README.md             # Project documentation and guide
```

---

## 📄 Dataset Format

When uploading a custom CSV file, ensure your file contains the following columns:

| Column Header | Data Type | Description |
| :--- | :--- | :--- |
| `Date` | Date / String (`YYYY-MM-DD`) | Date of the trading session |
| `Open` | Float / Numeric | Stock price at market open |
| `High` | Float / Numeric | Maximum stock price during the session |
| `Low` | Float / Numeric | Minimum stock price during the session |
| `Close` | Float / Numeric | Stock price at market close |
| `Volume` | Integer / Numeric | Number of shares traded |

*Note: The application automatically handles case-insensitive column headers and cleans invalid or missing records.*

---

## ⚙️ Installation & Setup

### 1. Clone or Navigate to the Project Directory
```bash
cd stock-market-analysis
```

### 2. (Recommended) Create a Virtual Environment
* **On Windows (PowerShell):**
  ```powershell
  python -m venv venv
  .\venv\Scripts\Activate.ps1
  ```
* **On macOS / Linux:**
  ```bash
  python3 -m venv venv
  source venv/bin/activate
  ```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

---

## ▶️ How to Run the Application

Start the Streamlit development server:

```bash
streamlit run app.py
```

Once executed, your default web browser will automatically open:
```text
http://localhost:8501
```

---

## ⚠️ Educational Disclaimer

This project is created strictly for **academic, educational, and learning purposes**. It is not intended for financial trading or investment advice. The bundled sample dataset contains synthetically generated prices labeled as sample data and should not be used as real-world market intelligence.
